
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ZNTCC' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"

/* Keil::Device:StdPeriph Drivers:ADC@3.6.0 */
#define RTE_DEVICE_STDPERIPH_ADC
/* Keil::Device:StdPeriph Drivers:FSMC@3.6.0 */
#define RTE_DEVICE_STDPERIPH_FSMC
/* Keil::Device:StdPeriph Drivers:Framework@3.6.0 */
#define RTE_DEVICE_STDPERIPH_FRAMEWORK
/* Keil::Device:StdPeriph Drivers:GPIO@3.6.0 */
#define RTE_DEVICE_STDPERIPH_GPIO
/* Keil::Device:StdPeriph Drivers:I2C@3.6.0 */
#define RTE_DEVICE_STDPERIPH_I2C
/* Keil::Device:StdPeriph Drivers:RCC@3.6.0 */
#define RTE_DEVICE_STDPERIPH_RCC
/* Keil::Device:StdPeriph Drivers:TIM@3.6.0 */
#define RTE_DEVICE_STDPERIPH_TIM


#endif /* RTE_COMPONENTS_H */
